package sandy.com.favouriteapp

import android.database.Cursor
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.ActionBar
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_favourite_detail.*

class FavouriteDetailActivity : AppCompatActivity() {
    private lateinit var favouriteDetail : FavouriteItem
    private lateinit var actionbar : ActionBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favourite_detail)

        favouriteDetail = intent.getParcelableExtra("detail") as FavouriteItem

        actionbar = supportActionBar as ActionBar

        setContent()
    }

    fun setContent(){
        if (actionbar != null) {
            actionbar.title = favouriteDetail.title
            actionbar.setDisplayHomeAsUpEnabled(true)
        }

        tvFavTitle.text = favouriteDetail.title
        tvFavDescription.text = favouriteDetail.overview
        tvFavRelease.text = favouriteDetail.releaseDate

        Glide.with(this)
            .load(favouriteDetail.posterUrl)
            .into(ivFavPoster)
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.bar_delete, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu1 -> {
                //Delete From Favourite
                val deleteUri : Uri = DatabaseContract.FavouriteColumns.CONTENT_URI
                    .buildUpon()
                    .appendPath(favouriteDetail.id.toString())
                    .build()

                contentResolver.delete(deleteUri, null, null)

                finish()
            }
            android.R.id.home ->{
                onBackPressed()
                return true
            }
            else -> return true
        }
        return true
    }
}
