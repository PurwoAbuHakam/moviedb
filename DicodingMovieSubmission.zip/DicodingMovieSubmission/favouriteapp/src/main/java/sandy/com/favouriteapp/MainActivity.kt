package sandy.com.favouriteapp

import android.content.ContentResolver
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private lateinit var rvMovies : RecyclerView
    private var listMovie: ArrayList<FavouriteItem> = arrayListOf()
    private lateinit var listMovieAdapter: ListFavouriteAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.title = getString(R.string.activity_title)

        rvMovies = findViewById(R.id.rv_movies_fav)
        rvMovies.setHasFixedSize(true)

        showRecyclerList()
    }

    override fun onResume() {
        super.onResume()

        getData()
    }

    private fun getData(){
        listMovie.clear()

        val favCursor: Cursor = contentResolver.query(
            DatabaseContract.FavouriteColumns.CONTENT_URI, null, null, null)

        favCursor.apply {
            while (moveToNext()) {
                val type = getInt(getColumnIndexOrThrow(DatabaseContract.FavouriteColumns.TYPE))
                val id = getInt(getColumnIndexOrThrow(DatabaseContract.FavouriteColumns._ID))
                val title = getString(getColumnIndexOrThrow(DatabaseContract.FavouriteColumns.TITLE))
                val releaseDate = getString(getColumnIndexOrThrow(DatabaseContract.FavouriteColumns.RELEASE_DATE))
                val overview = getString(getColumnIndexOrThrow(DatabaseContract.FavouriteColumns.OVERVIEW))
                val posterUrl = getString(getColumnIndexOrThrow(DatabaseContract.FavouriteColumns.POSTER_URL))
                listMovie.add(FavouriteItem(id, title, releaseDate, overview, posterUrl, type))
            }
        }

        listMovieAdapter.notifyDataSetChanged()
    }

    private fun showRecyclerList(){
        rvMovies.layoutManager = LinearLayoutManager(this)
        listMovieAdapter = ListFavouriteAdapter(this, listMovie)
        rvMovies.adapter = listMovieAdapter
    }
}
