package sandy.com.favouriteapp

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Created by Sandy Rizky on 05/03/2020.
 */

@Parcelize
data class FavouriteItem (
    var id: Int = 0,
    var title: String = "",
    var releaseDate: String = "",
    var overview: String = "",
    var posterUrl: String = "",
    var type: Int = 0
) : Parcelable