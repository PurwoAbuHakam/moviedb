package sandy.dicodingmoviesubmission.utils

import android.app.Application
import io.realm.Realm

/**
 * Created by Sandy Rizky on 03/03/2020.
 */
class MyApplication : Application(){

    override fun onCreate(){
        super.onCreate()
        Realm.init(this)
    }
}