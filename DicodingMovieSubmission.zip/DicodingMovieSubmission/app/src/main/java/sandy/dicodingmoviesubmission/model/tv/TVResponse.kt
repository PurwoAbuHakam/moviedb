package sandy.dicodingmoviesubmission.model.tv

/**
 * Created by Sandy Rizky on 24/02/2020.
 */

class TVResponse {
    var page: Int = 0
    var total_results: Int = 0
    var total_pages: Int = 0
    var results: List<TVResults> = arrayListOf()
}