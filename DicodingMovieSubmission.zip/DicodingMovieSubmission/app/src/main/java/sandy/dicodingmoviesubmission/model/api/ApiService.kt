package sandy.dicodingmoviesubmission.model.api

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import sandy.dicodingmoviesubmission.BuildConfig
import sandy.dicodingmoviesubmission.model.movie.MovieResponse
import sandy.dicodingmoviesubmission.model.tv.TVResponse
import sandy.dicodingmoviesubmission.utils.Constants

/**
 * Created by Sandy Rizky on 25/02/2020.
 */
interface ApiService {

    @GET("tv/popular")
    fun getTV(@Query("api_key") apiKey: String = BuildConfig.TMDB_API_KEY): Call<TVResponse>

    @GET("movie/popular")
    fun getMovie(@Query("api_key") apiKey: String = BuildConfig.TMDB_API_KEY): Call<MovieResponse>

    @GET("search/movie")
    fun searchMovie(@Query("api_key") apiKey: String = BuildConfig.TMDB_API_KEY,
                    @Query("language") lang: String = Constants.SEARCH_API_LANG,
                    @Query("query") query: String): Call<MovieResponse>

    @GET("search/tv")
    fun searchTV(@Query("api_key") apiKey: String = BuildConfig.TMDB_API_KEY,
                    @Query("language") lang: String = Constants.SEARCH_API_LANG,
                    @Query("query") query: String): Call<TVResponse>

    @GET("discover/movie")
    fun getNewRelease(@Query("api_key") apiKey: String = BuildConfig.TMDB_API_KEY,
                      @Query("primary_release_date.gte") rlsDateGte : String,
                      @Query("primary_release_date.lte") rlsDateLte : String): Call<MovieResponse>
}