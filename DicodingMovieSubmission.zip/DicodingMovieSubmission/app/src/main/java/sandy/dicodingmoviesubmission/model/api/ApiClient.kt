package sandy.dicodingmoviesubmission.model.api

import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import sandy.dicodingmoviesubmission.utils.Constants.Companion.BASE_URL

/**
 * Created by Sandy Rizky on 25/02/2020.
 */
object ApiClient {
    val instance: ApiService = Retrofit.Builder().run {
        val gson = GsonBuilder()
            .enableComplexMapKeySerialization()
            .setPrettyPrinting()
            .create()

        baseUrl(BASE_URL)
        addConverterFactory(GsonConverterFactory.create(gson))
        build()
    }.create(ApiService::class.java)
}